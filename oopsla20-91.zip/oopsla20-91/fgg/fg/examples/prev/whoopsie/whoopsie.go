//$ go run oopsla20-91/fgg -v fg/examples/prev/whoopsie/whoopsie.go

package main; type Bad struct { whoopsie Bad }; type A struct { }; func main() { _ = A{} }
