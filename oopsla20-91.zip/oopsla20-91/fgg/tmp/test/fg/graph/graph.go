package main;
import "fmt";
type Aᐸᐳ struct {};
type Top interface {};
func main() { fmt.Printf("%#v", Aᐸᐳ{}) }