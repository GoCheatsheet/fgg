package main;
import "fmt";
type Anyᐸᐳ interface {};
type Dummyᐸᐳ struct {};
func (x Dummyᐸᐳ) useInterfaceᐸᐳ(y IAᐸᐳ) Anyᐸᐳ { return y.m1ᐸSᐸᐳᐳ() };
func (x Dummyᐸᐳ) useInterface___IA___Any__() Top { return x };
type IAᐸᐳ interface { m1ᐸSᐸᐳᐳ() Sᐸᐳ; m1__a_Any____S__() Top };
type IBᐸᐳ interface { m1__a_Any____S__() Top; m2__a_Any____S__() Top };
type Sᐸᐳ struct {};
func (x Sᐸᐳ) m1ᐸSᐸᐳᐳ() Sᐸᐳ { return Sᐸᐳ{} };
func (x Sᐸᐳ) m1__a_Any____S__() Top { return x };
func (x Sᐸᐳ) m2__a_Any____S__() Top { return x };
type Top interface {};
func main() { fmt.Printf("%#v", Dummyᐸᐳ{}.useInterfaceᐸᐳ(Sᐸᐳ{}).(IBᐸᐳ)) }