package main;
import "fmt";
type BᐸAᐸᐳᐳ struct { val CᐸAᐸᐳᐳ };
type BᐸCᐸAᐸᐳᐳᐳ struct { val CᐸCᐸAᐸᐳᐳᐳ };
type CᐸCᐸAᐸᐳᐳᐳ struct {};
type CᐸAᐸᐳᐳ struct {};
func (x BᐸAᐸᐳᐳ) mᐸᐳ() BᐸCᐸAᐸᐳᐳᐳ { return BᐸCᐸAᐸᐳᐳᐳ{CᐸCᐸAᐸᐳᐳᐳ{}} };
func (x BᐸAᐸᐳᐳ) m___B_C_A____() Top { return x };
func (x BᐸCᐸAᐸᐳᐳᐳ) m___B_C_C_A_____() Top { return x };
type Top interface {};
func main() { fmt.Printf("%#v", BᐸAᐸᐳᐳ{CᐸAᐸᐳᐳ{}}.mᐸᐳ()) }