package main;
import "fmt";
type Dᐸᐳ struct {};
type Eᐸᐳ struct {};
type DtoEᐸᐳ struct {};
func (x0 DtoEᐸᐳ) applyᐸᐳ(d Dᐸᐳ) Eᐸᐳ { return Eᐸᐳ{} };
func (x0 DtoEᐸᐳ) apply___D___E__() Top { return x0 };
type Top interface {};
func main() { fmt.Printf("%#v", DtoEᐸᐳ{}.applyᐸᐳ(Dᐸᐳ{})) }