package main;
import "fmt";
type Intᐸᐳ struct {};
type Boolᐸᐳ struct {};
type IAᐸBoolᐸᐳᐳ interface { MyFunctionᐸIntᐸᐳᐳ(x Intᐸᐳ) Boolᐸᐳ; MyFunction__b_Any____α1_Bool__() Top };
type SBᐸᐳ struct {};
func (x SBᐸᐳ) MyFunctionᐸIntᐸᐳᐳ(y Intᐸᐳ) Boolᐸᐳ { return Boolᐸᐳ{} };
func (x SBᐸᐳ) MyFunction__b_Any____α1_Bool__() Top { return x };
type Dummyᐸᐳ struct {};
func (x Dummyᐸᐳ) CallFunctionBoolᐸᐳ(y IAᐸBoolᐸᐳᐳ) Boolᐸᐳ { return y.MyFunctionᐸIntᐸᐳᐳ(Intᐸᐳ{}) };
func (x Dummyᐸᐳ) CallFunctionBool___IA_Bool____Bool__() Top { return x };
type Top interface {};
func main() { fmt.Printf("%#v", Dummyᐸᐳ{}.CallFunctionBoolᐸᐳ(SBᐸᐳ{})) }