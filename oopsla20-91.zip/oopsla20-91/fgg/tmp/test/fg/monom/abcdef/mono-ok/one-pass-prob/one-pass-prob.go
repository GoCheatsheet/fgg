package main;
import "fmt";
type Intᐸᐳ struct {};
type PairᐸIntᐸᐳᐨIntᐸᐳᐳ struct { fst Intᐸᐳ; snd Intᐸᐳ };
type IAᐸᐳ interface { MyFunctionᐸIntᐸᐳᐳ(y Intᐸᐳ) Intᐸᐳ; MyFunction__b_Any____α1_Int__() Top };
type SAᐸᐳ struct {};
func (x SAᐸᐳ) MyFunctionᐸIntᐸᐳᐳ(y Intᐸᐳ) Intᐸᐳ { return PairᐸIntᐸᐳᐨIntᐸᐳᐳ{y, Intᐸᐳ{}}.snd };
func (x SAᐸᐳ) MyFunction__b_Any____α1_Int__() Top { return x };
type Dummyᐸᐳ struct {};
func (x Dummyᐸᐳ) CallFunctionᐸᐳ(y IAᐸᐳ) Intᐸᐳ { return y.MyFunctionᐸIntᐸᐳᐳ(Intᐸᐳ{}) };
func (x Dummyᐸᐳ) CallFunction___IA___Int__() Top { return x };
type Top interface {};
func main() { fmt.Printf("%#v", Dummyᐸᐳ{}.CallFunctionᐸᐳ(SAᐸᐳ{})) }